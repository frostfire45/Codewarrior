// queue.h  A character queue
void  initq(void);		// initialize the queue
void  qstore(char);		// store character in queue
int   qempty(void);		// return 0 if queue is not empty
char  getq(void);		// read character from queue

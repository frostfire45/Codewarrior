// Example 1a: Turn on every other segment on 7-seg display
#include <hidef.h>      /* common defines and macros */
#include <mc9s12dg256.h>     /* derivative information */
#pragma LINK_INFO DERIVATIVE "mc9s12dg256b"

#include "main_asm.h" /* interface to the assembly module */

  //char* TOPLINE;
char TLINE[17] = 
	{ "    00:00 AM    " };
	// 012345678901234
char BLINE[17] = 
	{ "Mon  Alarm: Off "};		
  
void DisplayTime(void);
void FullSec_Delay(void);

void main(void) {
    
  /* put your own code here */
  
  PLL_init();        // set system clock frequency to 24 MHz
  lcd_init();
  DisplayTime();
  for(;;) {} /* wait forever */
}

void DisplayTime()
{ 
	int i;
	char j; 	   
  	set_lcd_addr(0x00);
  	for(i = 0;i < 16;i++){
  		j = TLINE[i] ;
  		data8(j);
  	}
  	set_lcd_addr(0x40);
  	for(i = 0;i < 16;i++){
  		j = BLINE[i];
  		data8(j);  		
  	}
}
void FullSec_Delay(void){
	
}